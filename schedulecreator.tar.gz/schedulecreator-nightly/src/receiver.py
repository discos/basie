#coding=utf-8

#
#
#    Copyright (C) 2013  INAF -IRA Italian institute of radioastronomy, bartolini@ira.inaf.it
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

import logging
logger = logging.getLogger(__name__)

import utils

class Receiver(object):
    """
    represents a receiver and its characteristics
    """
    def __init__(self, name, fmin, fmax, beamsizetable=None, nfeed=2):
        """
        Constructor
        @param name: the receiver name, used as an unique ID
        @type name: string
        @param fmin: receiver minimum usable sky frequency (MHz)
        @type fmin: float
        @param fmax: receiver maximum usable sky frequency (MHz)
        @type fmax: float
        @param beamsizetable: a table of (frequency, beamsize) couples
        @type beamsizetable: L{utils.KVTable}
        """
        self.name = name
        self.fmin = fmin
        self.fmax = fmax
        self.nfeed = nfeed
        if beamsizetable:
            self.beamsize_table = utils.KVTable(beamsizetable)
        #TODO: tabella o polinomio freq:beamsize
        #beamsize di default calcolata per 1/2 RF

    @property
    def beamsize(self):
        """
        Get receiver default beamsize (calculated at self.fmin)
        """
        return self.get_beamsize() #at half bandwidth

    def get_beamsize(self, freq=None):
        """
        Get the beamsize for this receiver at a given frequency. 
        Read from beamsize_table the nearest frequency value.
        If freq is None defauls to self.fmin
        @param freq: frequency (MHz)
        @type freq: float
        @return: beamsize at given frequency
        """
        if not freq:
            logger.warning("RECEIVER %s using default beamsize at min frequency" %
                           (self.name,))
            #freq = (self.fmax + self.fmin) / 2.0
            freq = self.fmin
        if not self.fmin <= freq <= self.fmax:
            logger.warning("RECEIVER %s beamsize at frequency %f out of range" %
                           (self.name, freq,))
        return self.beamsize_table.nearest(freq)

MED = {
    'C' : Receiver('C', 4700, 5500,[(5000, 2.0)]),
    'CL': Receiver('CL', 4700, 5850, [(5200, 1.8)]),
    'X' : Receiver('X', 8180, 8980, [(8500, 0.8)]),
    'K' : Receiver('K', 18000, 26000, [(23000, 0.2)]),
}
"""
Module level variable which defines receivers in Medicina radiotelescope
"""

SRT = {
       'P' : Receiver('P', 305.0, 410.0, [(300, 1.070),
                                          (350, 0.937),
                                          (410, 0.818)]),
       'L' : Receiver('L', 1300.0, 1800.0, [(1300, 0.252),
                                            (1550, 0.210),
                                            (1800, 0.187)]),
       'C' : Receiver('C', 5700.0, 7700.0, [(5700, 0.053),
                                            (6700, 0.047),
                                            (7700, 0.043)]),
       'K' : Receiver('K', 18000.0, 26500.0, [(18000, 0.016),
                                              (22000, 0.014),
                                              (26000, 0.012)]),
       'KM' : Receiver('KM', 18000.0, 26500.0, [(18000, 0.016),
                                                (22000, 0.014),
                                                (26000, 0.012)],
                      nfeed = 14),
      }
"""
Module level variable which defines receivers in SRT radiotelescope
"""

NOTO = {}
"""
Module level variable which defines receivers in Noto radiotelescope
"""

receivers = dict(
                 MED = MED,
                 SRT = SRT,
                 NOTO = NOTO,
                )
