#coding=utf-8

#
#
#    Copyright (C) 2013  INAF -IRA Italian institute of radioastronomy, bartolini@ira.inaf.it
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

"""
This module implements logics related to angle representations and calculation
inside the schedule creator.
It enrich the angles python package (pip install angles) adding validating
options to the validate module and conversions from and to string.
"""

import re
import validate
import angles

dec_angle_pattern = "^[+-]?\d+(.\d+)?d$"
dec_angle_re = re.compile(dec_angle_pattern)
"""
Regular espression matching angle decimal representation
"""
dms_angle_pattern = "^(?P<deg>[+-]?\d{1,3}):" +\
                    "(?P<min>\d{2}):" +\
                    "(?P<sec>\d{2}(.\d+)?)$"
dms_angle_re = re.compile(dms_angle_pattern)
"""
Regular espression matching angle sexagesimal representation
"""
hms_angle_pattern = "^(?P<hour>[0-2]?\d)" +\
                    ":(?P<min>\d{2})" +\
                    ":(?P<sec>\d{2}(.\d+)?)h$"
hms_angle_re = re.compile(hms_angle_pattern)
"""
Regular espression matching angle sexagesimal representation in hour measures
"""

ANGLE_DECIMALS = 4
"""
Decimal angles digits
"""

class VdtAngleError(validate.ValidateError):
    """
    Raised when trying to parse a wrongly formatted angle
    """
    pass

def create_valid_angle(dec):
    """
    Function used to cread instances of angles.Angle class with given formatting
    attributes. Used in the schedule creator for every angle creation
    If dec is supplied as an angles.Angle instance returns a copy of the angle
    preserving every attribute including formatting options.
    @param dec: an angle
    @type dec: angles.Angle or float
    """
    a = angles.Angle()
    a.ounit = 'degrees'
    a.pre = ANGLE_DECIMALS
    a.trunc = False
    a.s1 = ':'
    a.s2 = ':'
    a.s3 = ''
    a.fmt = "dec"
    if isinstance(dec, angles.Angle):
        _dec = dec.d
        if hasattr(dec, "fmt"):
            a.fmt = dec.fmt
    else:
        _dec = dec
    a.d = _dec
    return a

ZERO_ANGLE = create_valid_angle(0.0)
"""
CONSTANT, used in schedule creator to represent the zero angle.
"""

def fmt_dec(angle):
    """
    Return the decimal string representation of the angle
    @param angle: an angle
    @type angle: angles.Angle
    """
    angle.ounit = "degrees"
    return str(angle.d) + "d"

def fmt_hms(angle):
    """
    Return the sexagesimal string representation of the angle in hours
    @param angle: an angle
    @type angle: angles.Angle
    """
    angle.ounit = "hours"
    return str(angle) + "h"

def fmt_dms(angle):
    """
    Return the sexagesimal string representation of the angle
    @param angle: an angle
    @type angle: angles.Angle
    """
    angle.ounit = "degrees"
    return str(angle)

def fmt_angle(angle):
    """
    Return a string representing the angle in its own format.
    @param angle: an angle
    @type angle: angles.Angle
    """
    if hasattr(angle, "fmt"):
        if angle.fmt == "hms":
            return fmt_hms(angle)
        elif angle.fmt == "dms":
            return fmt_dms(angle)
    return fmt_dec(angle)

def dms_to_angle(dms):
    """
    Get the angle from a tuple of numbers or strings giving its sexagesimal
    representation in degrees
    @param dms: (degrees, minutes, seconds)
    """
    angle_deg = int(dms[0])
    angle_min = int(dms[1])
    angle_sec = float(dms[2])
    if not 0 <= angle_min < 60:
        raise VdtAngleError("not a valid value for minutes: " + str(angle_min))
    if not 0 <= angle_sec < 60:
        raise VdtAngleError("not a valid value for seconds: " + str(angle_sec))
    if angle_deg >= 0:
        _sign = 1
    else:
        _sign = -1
    res = create_valid_angle(angles.sexa2deci(_sign, abs(angle_deg),
                                               angle_min, angle_sec))
    res.fmt = "dms"
    return res
    #return create_valid_angle(angle_deg + angle_min/60.0 + angle_sec/3600.0)
    #return ValidAngle(angle_deg + angle_min/60.0 + angle_sec/3600.0, orig="degrees")

def hms_to_angle(hms):
    """
    Get the angle from a tuple of numbers or strings giving its sexagesimal
    representation in hours
    @param hms: (degrees, minutes, seconds)
    """
    angle_hour = int(hms[0])
    angle_min = int(hms[1])
    angle_sec = float(hms[2])
    if not 0 <= angle_hour < 24:
        raise VdtAngleError("not a valid value for hours: " + str(angle_hour))
    if not 0 <= angle_min < 60:
        raise VdtAngleError("not a valid value for minutes: " + str(angle_min))
    if not 0 <= angle_sec < 60:
        raise VdtAngleError("not a valid value for seconds: " + str(angle_sec))
    if angle_hour >= 0:
        _sign = 1
    else:
        _sign = -1
    res = create_valid_angle(angles.sexa2deci(_sign, abs(angle_hour),
                                               angle_min, angle_sec, True))
    res.fmt = "hms"
    return res
    #return create_valid_angle(15 * (angle_hour + angle_min/60.0 + angle_sec/3600.0))
    #return ValidAngle(15 * (angle_hour + angle_min/60.0 + angle_sec/3600.0), orig="hours")

def check_dec_angle(value):
    """
    Validating function for angle decimal representation.
    Used in the rich_validator
    """
    if isinstance(value, list):
        raise validate.ValidateError("expected value angle, found list")
    if not dec_angle_re.match(value):
        raise VdtAngleError("not a valid decimal angle: %s" % value)
    return create_valid_angle(float(value[:-1]))
    #return ValidAngle(float(value[:-1]), orig="dec")

def check_dms_angle(value):
    """
    Validating function for angle sexagesimal representation in degrees.
    Used in the rich_validator
    """
    if isinstance(value, list):
        raise validate.ValidateError("expected value angle, found list")
    match = dms_angle_re.match(value)
    if not match:
        raise VdtAngleError("not a valid degrees angle: %s" % value)
    return dms_to_angle(match.groups())

def check_hms_angle(value):
    """
    Validating function for angle sexagesimal representation in hours.
    Used in the rich_validator
    """
    if isinstance(value, list):
        raise validate.ValidateError("expected value angle, found list")
    match = hms_angle_re.match(value)
    if not match:
        raise VdtAngleError("not a valid hour angle: %s" % value)
    return hms_to_angle(match.groups())

def check_angle(value):
    """
    validate a string to create an angles.Angle object
    tries in order: decimal, sexagesimal degrees and hours
    @return: the Angle object created
    @raise VdtAngleError: if value is not valid
    """
    try:
        a = check_dec_angle(value)
    except:
        try:
            a = check_dms_angle(value)
        except:
            try:
                a = check_hms_angle(value)
            except:
                raise
    return a

validate_options = {
    'angle' : check_angle,
    'dec_angle' : check_dec_angle,
    'dms_angle' : check_dms_angle,
    'hms_angle' : check_hms_angle,
}
"""
options added to the rich_validator and usable in .ini files
"""

