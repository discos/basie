#coding=utf-8

#
#
#    Copyright (C) 2013  INAF -IRA Italian institute of radioastronomy, bartolini@ira.inaf.it
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

"""
Utitlity functions.

functions:
    - get_user_templates: copy user template files
    - ceil_to_odd(dec): returns the nearest bigger odd int
    - ceil_to_half(dec): nearest bigger half unit
    - extrude_from_rectange: get a point outside of a rectangle, used for tsys 
classes:
    - KVTable: an ordered list of (key, value) pairs
"""

import math
import logging
import os
import shutil
logger = logging.getLogger(__name__)

PACKAGE_DIR = os.path.abspath(os.path.dirname(__file__))
USER_TEMPLATES_DIR = os.path.join(PACKAGE_DIR, "user_templates/")
SCHEMA_DIR = os.path.join(PACKAGE_DIR, "schemas/")

def get_user_templates(dst, force=False):
    """
    copy user template files into destination directory.
    If destination directory does not exists tries to create it.
    @param dst: the destination directory
    @param force: if True override present files
    """
    filenames = ("configuration.txt",
                 "targets.txt",)
    dst = os.path.abspath(dst)
    if not os.path.isdir(dst):
        logger.info("creating destination directory for templates: %s" % (dst,))
        os.makedirs(dst)
    for filename in filenames:
        write = True
        dstfile = os.path.join(dst, filename)
        srcfile = os.path.abspath(os.path.join(USER_TEMPLATES_DIR, filename))
        if os.path.isfile(dstfile):
            if not force:
                logger.warning("File exists %s" % (dstfile,))
                write = False
            else:
                logger.warning("Overriding file %s" % (dstfile,))
        if write:
            logger.info("write file: %s" % (dstfile,))
            shutil.copyfile(srcfile, dstfile)

def ceil_to_odd(dec):
    """
    @param dec: a floating point number
    @return: the minor integer odd number greater then dec.
    """
    n = math.ceil(dec)
    if n % 2 == 0:
        return int(n + 1)
    else:
        return int(n)

def ceil_to_half(dec):
    """
    @param dec: a floating point nunmber
    @return: the minor half unit bigger then dec
    """
    _ceil = math.ceil(dec)
    if (_ceil - 0.5) >= dec:
        return _ceil - 0.5
    else:
        return _ceil

def extrude_from_rectangle(x, y, extremes, delta):
    """
    project a point to the nearest side of a containing rectangle defined by the
    point in extremes
    @param x: x coordinate of the inner point
    @param y: y coordinate of the inner point
    @param extremes: [[x0, y0], ... [x3,y3]] coordinates of the extremes of a
    rectangle containing the point
    @param delta: how much to extrude the point from the polygon
    """
    #get distances from rectangle sides
    delta_x = [abs(x - e[0]) for e in extremes]
    delta_y = [abs(y - e[1]) for e in extremes]
    minx = min(delta_x)
    miny = min(delta_y)
    if minx <= miny: #we extrude moving on longitude axis
        _x = extremes[delta_x.index(minx)][0]
        if _x < x:
            _x -= delta
        elif _x > x:
            _x += delta
        else:#we are on right of left side of the rectangle
            left = True #suppose we are on the left side
            for _e in extremes:
                if _e[0] < _x:
                    left = False #we are on the right side
            if left:
                _x -= delta
            else:
                _x += delta
        ext = [_x, y]
    else: #we extrude moving on latitude axis
        _y_index = delta_y.index(miny)
        _y = extremes[_y_index][1]
        if _y < y:
            _y -= delta
        elif _y > y:
            _y += delta
        else:# We are on top of bottom side of the rectangle
            bottom = True #suppose we are on bottom side
            for _e in extremes:
                if _e[1] < _y:
                    bottom = False#we are on top side
            if bottom:
                _y -= delta
            else:
                _y += delta
        ext = [x, _y]
    return ext

def cmp_key(a, b):
    """
    Used to compare objects of (key, val) type.
    Keys must be comparable.
    @param a: (key, val) object
    @param b: (key, val) object
    """
    if a[0] < b[0]:
        return -1
    elif a[0] == b[0]:
        return 0
    else:
        return 1

class KVTable(object):
    """
    KVTable is an ordered list of key-value tuples such as:
    [(k1, v1), (k2, v2), (k3, v3) ... (kn, vn)]
    Where k1 < k2 < k3 ... < kn
    The list is kept in order upon new element insertion and no duplicate key is
    present.
    The only requirement is that keys should be comparable and subtractable
    between objects of the same type, thus it should be defined how k1 < k2
    and given a generic key we should be able to know the distance from
    another key as abs(key - k).
    """
    def __init__(self, kvtable):
        """
        Constructor.
        @param kvtable: an array of [(key, value) ... ]
        """
        self._table = kvtable
        self._table.sort(cmp=cmp_key)
        
    def insert(self, key, val):
        """
        Insert a new (key, value) pair in the table. Keep the table ordered.
        """
        self.pop(key)
        _index = 0
        while _index < len(self._table) and key > self._table[_index][0]:
            _index += 1
        if _index == len(self._table):
            _index += 1
        self._table.insert(_index, (key, val))

    def pop(self, key):
        """
        Removes the (key, value) couple from the list, if present.
        @param key: the key to be removed
        @return: value if key was present, None otherwise
        """
        _index = self._has_key(key)
        if _index >= 0:
            _, _val = self._table.pop(_index)
        else:
            _val = None
        return _val

    def nearest(self, key):
        """
        Given a generic key returns the value corresponding to the nearest key
        in the table
        @param key: the generic key
        @return: Value 
        """
        return self._table[self._nearest_index(key)][1]

    def keys(self):
        return [el[0] for el in self._table]

    def values(self):
        return [el[1] for el in self._table]

    def items(self):
        return self._table

    def has_key(self, key):
        """
        check if a key is present in the table
        @param key: the key to be searched
        @return: True or False
        """
        return self._has_key(key) >= 0

    def __iter__(self):
        for (k, v) in self._table:
            yield (k, v)

    def __str__(self):
        return str(self._table)

    def __setitem__(self, key, val):
        self.insert(key, val)

    def __len__(self):
        return len(self._table)

    def _has_key(self, key):
        """
        Check if key present in the list.
        @param key: the key to be searched for
        @return the key index if key was found, -1 otherwise
        """
        _index = 0
        while _index < len(self._table) and key > self._table[_index][0]:
            _index += 1
        if _index == len(self._table) or not self._table[_index][0] == key:
            return -1
        else:
            return _index

    def _nearest_index(self, key):
        _index = 0
        tlen = len(self._table)
        while _index < tlen and key > self._table[_index][0]:
            _index += 1
        if _index == len(self._table):
            return _index - 1
        elif self._table[_index][0] == key:
            return _index
        else:
            if abs(key - self._table[_index - 1][0]) < abs(self._table[_index][0] -
                                                      key):
                return _index - 1
            else:
                return _index

