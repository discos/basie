#coding=utf-8

"""
Radiotelescopes definitions and constants.
These should match values you find in the CDB.
Each radiotelescope is represented a dictionary containing:
    - max_acc: maximum acceleration obtained as root square sum of max
      acceleration in both axis
    - acc_scale_factor: scale factor used to overstimate maximum acceleration
    - receivers: receivers as defined in L{receiver} module
"""

import math

import receiver

MED = dict(
           max_acc = math.sqrt(0.4 ** 2 + 0.5 ** 2),
           acc_scale_factor = 15, #this value is highly abundant
           receivers = receiver.MED,
          )
"""
Medicina radiotelescope constants
"""

NOTO = dict(
           max_acc = math.sqrt(0.4 ** 2 + 0.5 ** 2),
           acc_scale_factor = 10,
           receivers = receiver.NOTO,
          )
"""
Noto radiotelescope constants
"""

SRT = dict(
           max_acc = math.sqrt(0.4 ** 2 + 0.25 ** 2),
           acc_scale_factor = 15,
           receivers = receiver.SRT,
          )
"""
SRT radiotelescope constants
"""


