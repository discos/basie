#coding=utf-8

#
#
#    Copyright (C) 2013  INAF -IRA Italian institute of radioastronomy, bartolini@ira.inaf.it
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

"""
Subscan related classes and funcions:
B{Classes}
    - SubscanError
    - Subscan: a generic subscan 
        - OTFSubscan: a generic on the fly subscan
        - SiderealSubscan: a generic sidereal subscan
B{Functions}
Used to get subscan classes instances. Subscans are often returned in couples
together with their associated Tsys sidereal subscan.
    - get_cen_otf_subscan
    - get_ss_otf_subscan (not implemented)
    - get_sidereal_subscan
    - get_tsys_subscan
    - get_couple_subscan
    - get_sid_couple_subscan
"""

import logging
logger = logging.getLogger(__name__)

import valid_angles
import templates
import frame
import utils
import target

TSYS_SIGMA = 5
"""
Used for calculating TSYS subscans coordinate offsets as TSYS_SIGMA * beamsize
"""

class SubscanError(Exception):
    def __init__(self, *args, **kwargs):
        Exception.__init__(self, *args, **kwargs)

class Subscan(object):
    """
    Generci subscan. Contains common subscan attributes and is meant to be
    override by specific subscan classes
    """
    ID = 1 #static counter attribute 
    def __init__(self, _target, typename, duration=0.0, is_tsys=False):
        """
        Constructor.
        Give the subscan a unique ID.
        """
        self.ID = Subscan.ID #This value will be the same found in the lis file
        Subscan.ID += 1
        self.target = _target
        self.typename = typename
        self.is_tsys = is_tsys
        self.duration = duration

class OTFSubscan(Subscan):
    """
    On the flight sunbscan class
    """
    def __init__(self, _target, lon2, lat2, descr, scan_frame,
                 geom, direction, duration, is_tsys = False):
        """
        Constructor.
        """
        Subscan.__init__(self, _target, "OTF", duration, is_tsys)
        self.scan_frame = scan_frame
        #check that offset frame and scan frame are equal
        if not self.target.offset_coord.frame:#default behaviour
            self.target.offset_coord.frame = self.scan_frame
        if not self.target.offset_coord.frame == self.scan_frame:
            msg = "offset frame %s different from scan frame %s" % (self.target.offset_coord.frame.name, self.scan_frame)
            logger.debug(msg)
            raise SubscanError(msg)
        self.lon2 = lon2
        self.lat2 = lat2
        self.descr = descr.upper()
        #check consistnecy of frames specifications
        #we already know that offset and scan 
        if not self.target.coord.frame == self.scan_frame:#possible mistake!
            logger.warning("SUBSCAN %d : scan_frame and coordinates_frame are different" % (self.ID,))
            if (self.target.coord.frame == frame.EQ and 
                self.descr == "CEN" and 
                self.scan_frame == frame.HOR):
                pass #OK - only success condition
            else:
                raise SubscanError("not compatible frame types")#very bad ;) 
        self.geom = geom
        self.direction = direction
        logger.debug("subscan offsets %f %f" % (_target.offset_coord.lon.d,
                                                _target.offset_coord.lat.d))

    def __str__(self):
        _lon1, _lat1 = self.target.coord.fmt()
        _offset_lon = valid_angles.fmt_dec(self.target.offset_coord.lon)
        _offset_lat = valid_angles.fmt_dec(self.target.offset_coord.lat)
        return templates.otf_subscan.substitute(
                    dict(
                         ID = self.ID,
                         target = self.target.label,
                         lon1 = _lon1,
                         lat1 = _lat1,
                         lon2 = valid_angles.fmt_angle(self.lon2),
                         lat2 = valid_angles.fmt_angle(self.lat2),
                         frame = self.target.coord.frame.name,
                         s_frame = self.scan_frame.name,
                         geom = self.geom,
                         descr = self.descr,
                         direction = self.direction,
                         duration = str(self.duration),
                         offset_frame = self.target.offset_coord.frame.offset_name,
                         offset_lon = _offset_lon,
                         offset_lat = _offset_lat,
                    )
                )

class SiderealSubscan(Subscan):
    def __init__(self, _target, duration=0.0, is_tsys=False):
        Subscan.__init__(self, _target, "SIDEREAL", duration, is_tsys)
        logger.debug("subscan offsets %f %f" % (_target.offset_coord.lon.d,
                                                _target.offset_coord.lat.d))

    def __str__(self):
        _lon, _lat = self.target.coord.fmt()
        _offset_lon = valid_angles.fmt_dec(self.target.offset_coord.lon)
        _offset_lat = valid_angles.fmt_dec(self.target.offset_coord.lat)
        if self.target.coord.frame == frame.EQ:
            _epoch = str(self.target.epoch) + '\t'
        else:
            _epoch = ""
        return templates.sidereal_subscan.substitute(
            dict(
                 ID = self.ID,
                 target = self.target.label,
                 frame = self.target.coord.frame.name,
                 longitude = _lon,
                 latitude = _lat,
                 epoch = _epoch,
                 offset_frame = self.target.offset_coord.frame.offset_name,
                 offset_lon = _offset_lon,
                 offset_lat = _offset_lat,
            )
        )

def get_cen_otf_subscan(_target, 
                        duration, 
                        length, 
                        offset, 
                        const_axis, 
                        direction,
                       scan_frame):
    """
    Get an I{OTF} subscan with description I{CEN}.
    @return: an L{OTFSubscan} instance
    """
    __target = target.copy(_target)
    if const_axis == "LON":
        __target.offset_coord.lon = valid_angles.create_valid_angle(
                                                             _target.offset_coord.lon +
                                                             offset)
        logger.debug("offset lon: %f" % (__target.offset_coord.lon.d,))
        lon2 = valid_angles.ZERO_ANGLE
        lat2 = length
    elif const_axis == "LAT":
        __target.offset_coord.lat = valid_angles.create_valid_angle(
                                                             _target.offset_coord.lat +
                                                             offset)
        logger.debug("offset lat: %f" % (__target.offset_coord.lat.d,))
        lon2 = length
        lat2 = valid_angles.ZERO_ANGLE
    attr = dict(_target = __target,
                descr = 'CEN',
                duration = duration,
                lon2 = lon2,
                lat2 = lat2,
                geom = const_axis,
                direction = direction,
                scan_frame = scan_frame,
               )
    return OTFSubscan(**attr)

def get_ss_otf_subscan(*args, **kwargs):
    """
    @raise NotImplementedError: we still have no useful case for implemting this
    function
    """
    raise NotImplementedError("is there any useful case for implementing this?")

def get_sidereal_subscan(_target, offset_lon, offset_lat, duration=0.0, is_tsys=False):
    """
    @param _target: the subscan target
    @type _target: target.Target
    @param offset_lon: additionale longitude offset
    @type offset_lon: angles.Angle
    @param offset_lat: additional latitude offset
    @type offset_lat: angles.Angle
    """
    __target = target.copy(_target)
    __target.offset_coord.lon = valid_angles.create_valid_angle(
                                                        __target.offset_coord.lon +
                                                        offset_lon)
    __target.offset_coord.lat = valid_angles.create_valid_angle(
                                                        __target.offset_coord.lat +
                                                        offset_lat)
    return SiderealSubscan(__target, duration, is_tsys)

def get_tsys_subscan(_target, offset_lon, offset_lat, duration=0.0):
    """
    Get a Tsys subscan.
    This basically returns a SIDEREAL subscan where source name is I{Tsys} and
    duration is I{0.0}
    """
    __target = target.copy(_target)
    __target.label = "Tsys"
    return get_sidereal_subscan(__target, offset_lon, offset_lat, duration=0.0, is_tsys=True)

def get_couple_subscan(_target, 
                       duration, 
                       length, 
                       offset, 
                       const_axis, 
                       direction,
                       scan_frame, 
                       beamsize):
    """
    Get a couple composed of a CEN_OTF subscan and its relative SIDEREAL TSYS
    subscan.
    @return: (otf_subscan, tsys_subscan)
    """
    logger.debug("get couple subscan offset: %f " % (offset.d,))
    negative_offset = valid_angles.create_valid_angle(-1 * (length.d / 2.0 +
                                                                beamsize *
                                                                TSYS_SIGMA))
    positive_offset = valid_angles.create_valid_angle(length.d / 2.0 +
                                                                beamsize *
                                                                TSYS_SIGMA)
    if const_axis == "LAT":
        _offset_lat = offset
        if direction == "INC":
            _offset_lon = negative_offset
        elif direction == "DEC":
            _offset_lon = positive_offset
    elif const_axis == "LON":
        _offset_lon = offset
        if direction == "INC":
            _offset_lat = negative_offset
        elif direction == "DEC":
            _offset_lat = positive_offset
    ss = get_cen_otf_subscan(_target, duration, length, offset, const_axis,
                             direction, scan_frame)
    st = get_tsys_subscan(_target, _offset_lon, _offset_lat)
    return ss, st

def get_sid_couple_subscan(_target, 
                           offset_lon, 
                           offset_lat, 
                           extremes, 
                           duration,
                           beamsize):
    """
    Get a couple of sidereal subscans, where the first is an actual subscan and the
    second is a tsys subscan obtained pointing the antenna out of a rectangular
    polygon containing the source.
    @param _target: the source to be observed
    @type _target: L{target.Target}
    @param offset_lon: longitude offset of the subscan
    @param offset_lat: latitude offset of the subscan
    @param extremes: An array containing the offsets of the extremes of the rectangular polygon
    containing the source (i.e. the borders of a raster map) 
    @type extremes: [(x0,y0), (x1,y1), (x2,y2), (x3,y3)]
    @param duration: subscan duration (Sec. ) 
    @type duration: float
    @param beamsize: beam size used to calculated tsys subscan offsets
    """
    ss = get_sidereal_subscan(_target, offset_lon, offset_lat, duration)
    tsys_offsets = utils.extrude_from_rectangle(offset_lon.d, offset_lat.d,
                                                extremes, beamsize * TSYS_SIGMA)
    _tsys = (valid_angles.create_valid_angle(tsys_offsets[0]),
            valid_angles.create_valid_angle(tsys_offsets[1]))
    st = get_tsys_subscan(_target, _tsys[0], _tsys[1])
    return ss, st

