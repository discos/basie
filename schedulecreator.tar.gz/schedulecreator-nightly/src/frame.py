#coding=utf-8

#
#
#    Copyright (C) 2013  INAF -IRA Italian institute of radioastronomy, bartolini@ira.inaf.it
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
"""
Module incapsulating all coordinates logics. 
Depends on pyephem for coordinate conversions between galactic and equatorial
systems.

exported classes:
    - Frame - a coordinate frame
    - Coord - coordinates with a frame
exported constants:
    - frames
    - EQ, GAL, HOR
    - axes
"""

import logging
logger = logging.getLogger(__name__)

try:
    import ephem 
except:
    ephem = None

import valid_angles

class Frame(object):
    """
    Frame object containing coordinates names for a given frame
    """
    #def __init__(self, name , lon, lat, offset, fmt_lon=valid_angles.fmt_dec,
    #             fmt_lat=valid_angles.fmt_dec):
    def __init__(self, name , lon, lat, offset):
        """
        Constructor
        @param name: one of EQ, GAL, HOR the frame system name
        @param lon: one of RA, LON, AZ longitude coordinate name
        @param lat: one of DEC, LAT, EL latitude coordinate name
        @param offset: the label used in the schedule to make an offset frame
        """
        self.name = name
        self.lon_name = lon
        self.lat_name = lat
        self.offset_name = offset
        #self.fmt_lon = fmt_lon
        #self.fmt_lat = fmt_lat

    @property
    def axes(self):
        """
        (self.lon_name, self.lat_name)
        """
        return (self.lon_name, self.lat_name)

    def __str__(self):
        return self.name

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.name == other.name
    
    def __ne__(self, other):
        return not self.__eq__(other)

#EQ = Frame('EQ', 'RA', 'DEC', '-EQOFFS', valid_angles.fmt_hms,
#           valid_angles.fmt_dms)
EQ = Frame('EQ', 'RA', 'DEC', '-EQOFFS')
"""
Equaltorial coordinate frame
"""

#GAL = Frame('GAL', 'LON', 'LAT', '-GALOFFS', valid_angles.fmt_dms,
#            valid_angles.fmt_dms)
GAL = Frame('GAL', 'LON', 'LAT', '-GALOFFS')
"""
Galactic coordinate frame
"""

#HOR = Frame('HOR', 'AZ', 'EL', '-HOROFFS', valid_angles.fmt_dec,
#            valid_angles.fmt_dec)
HOR = Frame('HOR', 'AZ', 'EL', '-HOROFFS')
"""
Horizontal coordinate frame
"""

frames = {
    'EQ' : EQ,
    'GAL' : GAL,
    'HOR' : HOR,
}
"""
frames dictionary
"""

axes = ('LON', 'LAT', 'RA', 'DEC', 'AZ', 'EL', 'BOTH')
"""
All possible value for axis label, including \"BOTH\"
"""

class CoordinateError(Exception):
    """
    Used when illegal operations are done with coordinates objects
    """
    def __init__(self, *args, **kwargs):
        Exception.__init__(self, *args, **kwargs)

class Coord(object):
    """
    Stores a coordinate couple associated with their reference frame and epoch.
    @param frame: a coordinate frame
    @type frame: Frame
    @param lon: longitude component
    @type lon: angles.Angle
    @param lat: latitude component
    @type lat: angles.Angle
    @param epoch: coordinates epoch defaults to j2000
    """
    def __init__(self, frame=EQ, lon=valid_angles.create_valid_angle(0.0),
                 lat=valid_angles.create_valid_angle(0.0), epoch="j2000"):
        #TODO: should epoch be a real object i.e. ephem.J2000 ?
        self.frame = frame
        self.lon = valid_angles.create_valid_angle(lon)
        self.lat = valid_angles.create_valid_angle(lat)
    
    def __lt__(self, other):
        if not isinstance(other, Coord):
            return NotImplemented
        if not self.frame == other.frame:
            raise CoordinateError("cannot compare coordinates of different frames")
        #TODO: should we try and force coordinate conversion?
        return (self.lon.r, self.lat.r) < (other.lon.r, other.lat.r)
    
    def __gt__(self, other):
        return not self.__lt__(other)

    def __eq__(self, other):
        return not self.__lt__(other) and not other.__lt__(self)

    def __ne__(self, other):
        return not self.__eq__(other)

    def __le__(self, other):
        return self.__lt__(other) or self.__eq__(other)

    def __ge__(self, other):
        return self.__gt__(other) or self.__eq__(other)

    def __str__(self):
        res = "%s lon: %s lat: %s" % (self.frame.name, 
                                      valid_angles.fmt_angle(self.lon),
                                      valid_angles.fmt_angle(self.lat),
                                      #self.frame.fmt_lon(self.lon),
                                      #self.frame.fmt_lat(self.lat),
                                     )
        return res

    def fmt(self):
        """
        Returns formatted (lon, lat)
        """
        #return (self.frame.fmt_lon(self.lon),
        #        self.frame.fmt_lat(self.lat))
        return (valid_angles.fmt_angle(self.lon),
                valid_angles.fmt_angle(self.lat))

    def transform(self, dest_frame):
        """
        conversion between different coordinate frame systems
        @param dest_frame: the output frame system 
        @type dest_frame: Frame
        """
        logger.debug("transofrm coordinates from %s to %s" % (self.frame.name,
                                                              dest_frame.name))
        if not ephem:
            logger.error("Module pyephem is not installed, cannot convert coordinates between different frames")
            return
        if dest_frame == self.frame:
            return #nothing to do 
        legal = True
        if self.frame == EQ:
            if dest_frame == GAL:
                t1 = ephem.Equatorial(self.lon.r, self.lat.r)
                self.frame = GAL
                t2 = ephem.Galactic(t1)
                self.lon = valid_angles.create_valid_angle(t2.lon)
                self.lat = valid_angles.create_valid_angle(t2.lat)
            else:
                legal = False
        elif self.frame == GAL:
            if dest_frame == EQ:
                t1 = ephem.Galactic(self.lon, self.lat)
                self.frame = EQ
                t2 = ephem.Equatorial(t1)
                self.lon = valid_angles.create_valid_angle(t2.ra)
                self.lat = valid_angles.create_valid_angle(t2.dec)
            else:
                legal = False
        else: #self.frame == frame.HOR
            legal = False #cannot convert to celestial coordinates without date
        if not legal:
            msg = "Cannot convert coordinates from %s to %s" % (self.frame.name, dest_frame.name,)
            logger.error(msg)
            raise CoordinateError(msg)

def copy_coord(other):
    return Coord(other.frame, other.lon, other.lat)

