#coding=utf-8

#
#
#    Copyright (C) 2013  INAF -IRA Italian institute of radioastronomy, bartolini@ira.inaf.it
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

import logging
logger = logging.getLogger(__name__)
import os

import target
import templates
import procedures
import radiotelescopes
import utils
from backend import TotalPowerBackend

class ScheduleError(Exception):
    def __init__(self, *args, **kwargs):
        Exception.__init__(self, *args, **kwargs)

class Schedule(object):
    """
    A whole scheduled activity, 
    comprises scans definitions and targets parsed from spec file.
    Has methods for writing output schedule files.
    """
    def __init__(self, projectID, observer, scheduleLabel, radiotelescope, receiver,
                 scheduleRuns, outputFormat, targetsFile, backend, scans, tsys,
                 repetitions):
        """
        Constructor
        @param projectID: project identification
        @param observer: name of the observer
        @param scheduleLabel: a label for identifying this partidoular schedule
        within the project
        @param radiotelescope: one of MED, SRT, NOTO
        @param receiver: a receiver for the radiotelescope
        @param scheduleRuns: how many times to run the schedule consecutively
        @param outputFormat: one of fits or mbfits
        @param targetsFile: name of the target file located in the same
        directory of the schedule file
        @param scans: scans definitions as parsed from schedule file
        @param tsys: default tsys value
        @param repetitions: default repetitions value
        """
        self.projectID = projectID
        self.observer = observer
        self.label = scheduleLabel
        try:
            self.radiotelescope = getattr(radiotelescopes, radiotelescope)
        #load receiver configuration for selected radiotelescope
        except:
            raise ScheduleError("Radiotelescope %s is not defined " %
                                radiotelescope)
        try:
            self.receiver = self.radiotelescope['receivers'][receiver]
        except:
            raise ScheduleError("Cannot find receiver %s" % receiver)
        self.scheduleRuns = scheduleRuns
        self.repetitions = repetitions
        self.tsys = tsys
        self.output_format = outputFormat.lower()
        self.scans = scans
        #Get targets from specified file
        self.targets = target.parse(targetsFile)
        for (_target, _, _) in self.targets:
            if not _target.tsys:
                _target.tsys = self.tsys
            if not _target.repetitions:
                _target.repetitions = self.repetitions
        self.base_dir = os.path.abspath('.')
        #Get backend configuration
        self.backend = TotalPowerBackend("STD",
                                         backend['integration'],
                                         backend['samplingInterval'])
        self.backend.set_sections(self.receiver.nfeed, backend['bandwidth'])
        #explode 'BOTH' scans into 2 separate scans
        #TODO: should this be a separate 'check' function?
        for _scan_name, _scan in self.scans.iteritems():
            if isinstance(_scan, tuple): #only BOTH scans return a tuple
                logger.info("exploding scan %s in 2 separate scans" % (_scan_name,))
                self.scans.pop(_scan_name)
                if ((_scan_name + "_lon" in self.scans) or 
                    (_scan_name + "_lat" in self.scans)):
                    raise ScheduleError("Cannot explode scan %s in separate subscans" % (_scan_name,))
                self.scans[_scan_name + "_lon"] = _scan[0]
                self.scans[_scan_name + "_lat"] = _scan[1]
                #explode 'BOTH' targets into 2 separate targets
                while _scan_name in [_target_scan_name 
                                     for (_, _target_scan_name, _)
                                     in self.targets]:
                    index = [_tsn for (_, _tsn, _) in self.targets].index(_scan_name)
                    _target, _scan_name, _line = self.targets[index]
                    logger.info("Exploding target %s in two separate targets" % (_target.label,))
                    self.targets[index] = (_target,
                                           _scan_name + "_lat",
                                           _line)
                    self.targets.insert(index, (_target, 
                                                _scan_name + "_lon",
                                                _line))

    def set_base_dir(self, base_path):
        """
        Set the output directory for the schedule files.
        Creates the directory if it does not exist
        @param base_path: the path (relative or absolute) of the output
        directory
        """
        abs_path = os.path.abspath(base_path)
        if not os.path.isdir(abs_path):
            os.mkdir(abs_path)
        logger.debug("base output path set to %s" % (abs_path,))
        self.base_dir = abs_path

    def _write_schedule_files(self):
        """
        Method including the logics of schedule file creation.
        
        """
        scdfilename = os.path.join(self.base_dir, "%s.scd" % (self.label,))
        lisfilename = os.path.join(self.base_dir, "%s.lis" % (self.label,))
        cfgfilename = os.path.join(self.base_dir, "%s.cfg" % (self.label,))
        bckfilename = os.path.join(self.base_dir, "%s.bck" % (self.label,))
        datfilename = os.path.join(self.base_dir, "%s.dat" % (self.label,))
        bckfile = open(bckfilename, "wt")
        bckfile.write(str(self.backend))
        bckfile.close()
        scdfile = open(scdfilename, "wt")
        lisfile = open(lisfilename, "wt")
        #WRITE SCD HEADER
        scdfile.write(templates.scd_header.substitute(
                              dict(
                                projectID = self.projectID,
                                observer = self.observer,
                                lisfilename = os.path.basename(lisfilename),
                                cfgfilename = os.path.basename(cfgfilename),
                                bckfilename = os.path.basename(bckfilename),
                                initproc = "procedure_init",
                                  )))
        if self.output_format == "mbfits":
            scdfile.write("SCANLAYOUT: schedule.dat\n")
        scdfile.write("\n")

        #WRITE SCAN AND SUBSCANS INFORMATIONS SEQUENTIALLY
        scan_number = 1
        _used_procedures = set()
        #BEGIN SCANS LOOP
        for _target, _scantype, _line in self.targets:
            subscan_number = 1
            #WRITE SCD SCAN HEADER
            scdfile.write("\nSC:\t%d\t%s\t" % (scan_number, _target.label))
            if self.output_format == "mbfits":
                scanlayout = "scanlayout_%d_%s" % (scan_number, _target.label)
                scdfile.write("STD:MANAGEMENT/MBFitsWriter\t%s\n" % (scanlayout,))
            else:
                scdfile.write("STD:MANAGEMENT/FitsZilla\n")
            #BEGIN SUBSCANS LOOP
            subscans_set = set()
            try:
                _scan = self.scans[_scantype]
            except KeyError:
                raise ScheduleError("Cannot find scan: %s" % (_scantype, )) 
            for _subscan in _scan.iter_subscans(_target, self.receiver.beamsize):
                #ADD THE SUBSCAN TO THE SET OF USED ONES
                subscans_set.add(_subscan)
                #WRITE SUBSCAN IN SCD FILE
                if _subscan.is_tsys:
                    #ADD TSYS post subscan proceudure
                    procedure = procedures.TSYS()
                    _used_procedures.add(procedures.TSYS)
                elif _subscan.typename == "OTF":
                    #ADD WAIT post subscan proceudure
                    wait_time = (((_scan.speed / 60.0) /
                        self.radiotelescope['max_acc']) *
                        self.radiotelescope['acc_scale_factor'])
                    wait_time = utils.ceil_to_half(wait_time)
                    procedure = procedures.WAIT(wait_time)
                    _used_procedures.add(procedures.WAIT)
                else:
                    procedure = "NULL"
                scdfile.write("%d_%d\t%f\t%d\tNULL\t%s\n" % (
                                                            scan_number,
                                                            subscan_number,
                                                            _subscan.duration,
                                                            _subscan.ID,
                                                            procedure,
                                                            ))
                subscan_number += 1
                #END SUBSCANS LOOP
            #WRITE SUBSCANS TO LIS FILE
            subscans_list = list(subscans_set)
            subscans_list.sort(key = lambda x: x.ID) #GET SUBSCANS SORTED BY ID
            lisfile.write("#%s\n" % (_target.label,))
            for _subscan in subscans_list:
                lisfile.write(str(_subscan))
                lisfile.write("\n")
            scan_number += 1
            #END SCANS LOOP
        scdfile.close()
        lisfile.close()
        cfgfile = open(cfgfilename, "wt")
        for _p in _used_procedures:
            cfgfile.write(str(_p))
        cfgfile.close()

