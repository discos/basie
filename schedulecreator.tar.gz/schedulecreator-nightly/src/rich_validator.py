#coding=utf-8

#
#
#    Copyright (C) 2013  INAF -IRA Italian institute of radioastronomy, bartolini@ira.inaf.it
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

"""
This module extends the validate options used to parse schedule creator
arguments from configuration file.
In particular it adds new possible instances to be used in the .ini schemas
files.
"""

import logging
logger = logging.getLogger(__name__)

import os
import re
import datetime
import configobj
import validate as v

import valid_angles
import frame
import scan
import utils

valid_list_element = re.compile("[^\s,]+")
"""
regular expression matching list items separated by whitespace characters or
\',\'
"""

def string2list(value):
    """
    @param value: a list of items separated by \',\' or whitespaces
    @type value: string
    @return: [first, second, third ... ]
    """
    value_list = valid_list_element.findall(value)
    return value_list

def check_frame(value):
    """
    Convert a string to a frame.Frame instance.
    Used as a validating function
    """
    if isinstance(value, list):
        raise v.ValidateError("expected frame value, found list")
    value = value.upper()
    if not value in frame.frames:
        raise v.ValidateError("%s is not a valid frame" % (value,))
    return frame.frames[value]

def check_cross_scan(value):
    if not isinstance(value, list):
        raise v.ValidateError("expected list, found  %s" % (value,))
    _frame = check_frame(value[0])
    length = valid_angles.check_angle(value[1])
    speed = v.is_float(value[2])
    return scan.CrossScan(_frame, length, speed)

def check_otf_map(value):
    if not isinstance(value, list):
        raise v.ValidateError("expected list, found  %s" % (value,))
    _frame = check_frame(value[0]) 
    scan_axis = value[1].upper()
    if not scan_axis in frame.axes:
        raise v.ValidateError("not a valid axis: %s" % (scan_axis,))
    start_point = value[2].upper()
    if not start_point in scan.START_POINTS:
        raise v.ValidateError("not a valid start point: %s" % (start_point,))
    length_x = valid_angles.check_angle(value[3])
    length_y = valid_angles.check_angle(value[4])
    speed = v.is_float(value[5], min=0)
    spacing = valid_angles.check_angle(value[6])
    if scan_axis == "BOTH":
        return (scan.OTFMapScan(_frame, start_point, _frame.lon_name, length_x, length_y,
                           spacing, speed),
                scan.OTFMapScan(_frame, start_point, _frame.lat_name, length_x, length_y,
                           spacing, speed))
    else:
        return scan.OTFMapScan(_frame, start_point, scan_axis, length_x, length_y,
                           spacing, speed)

def check_raster_map(value):
    if not isinstance(value, list):
        raise v.ValidateError("expected list, found  %s" % (value,))
    _frame = check_frame(value[0]) 
    scan_axis = value[1].upper()
    if not scan_axis in frame.axes:
        raise v.ValidateError("not a valid axis: %s" % (scan_axis,))
    start_point = value[2].upper()
    if not start_point in scan.START_POINTS:
        raise v.ValidateError("not a valid start point: %s" % (start_point,))
    length_x = valid_angles.check_angle(value[3])
    length_y = valid_angles.check_angle(value[4])
    duration = v.is_float(value[5], min=0)
    spacing = valid_angles.check_angle(value[6])
    return scan.RasterMapScan(_frame, start_point, scan_axis, length_x, length_y,
                       spacing, duration)

def check_onoff(value):
    return value

def check_scan(value):
    if not isinstance(value, list):
        value = string2list(value)
    scantype = value[0].upper()
    if scantype == "CROSS":
        return check_cross_scan(value[1:])
    elif scantype == "OTFMAP":
        return check_otf_map(value[1:])
    elif scantype == "RASTERMAP":
        return check_raster_map(value[1:])
    elif scantype == "ONOFF":
        return check_onoff(value[1:])
    raise v.ValidateError("unknow scan type %s" % (scantype,))

def check_file(value):
    if isinstance(value, list):
        raise v.ValidateError("expected value filename, found list")
    if not os.path.isfile(value):
        raise v.ValidateError("%s is not a valid file" % (value,))
    return value

filename_pattern = re.compile("^[" + os.sep + "_a-zA-Z0-9.-]+$")
def check_filename(value):
    if isinstance(value, list):
        raise v.ValidateError("expected value filename, found list")
    if not filename_pattern.match(value):
        raise v.ValidateError("not a valid filename: %s" % (value,))
    return value

date_pattern = re.compile("^\d{2}-\d{2}-\d{4}")
def check_date(value):
    if isinstance(value, list):
        raise v.ValidateError("expected date value, found list")
    if not date_pattern.match(value):
        raise v.ValidateError("not a valid date format: %s" % (value,))
    try:
        date = datetime.datetime.strptime(value, "%d-%m-%Y")
        date = date.date()
    except:
        raise v.ValidateError("not a valid date: %s" % (value,))
    return date

def check_future_date(value):
    date = check_date(value)
    if date < datetime.date.today():
        raise v.ValidateError("date %s is in the past" % (value,))
    return date

valid_types = {
    'frame' : check_frame,
    'scan' : check_scan,
    'file' : check_file,
    'filename' : check_filename,
    'date' : check_date,
    'future_date' : check_future_date,
}
valid_types.update(valid_angles.validate_options)
rich_validator = v.Validator(valid_types)

def validate(filename, specfilename):#, error_stream=sys.stderr):
    conf = configobj.ConfigObj(filename, configspec=specfilename)
    res = conf.validate(rich_validator, preserve_errors=True)
    if not res == True:
        flat_errs = configobj.flatten_errors(conf, res)
        for _, var, ex in flat_errs:
            #error_stream.write(var)
            #error_stream.write(": ")
            #error_stream.write(str(ex))
            #error_stream.write("\n")
            logger.error("%s : %s\n" % (var, str(ex)))
        raise v.ValidateError("Could not validate %s vs %s" % (filename, specfilename))
    return conf

def validate_schedule(filename):
    return validate(filename, os.path.join(utils.SCHEMA_DIR, "schedule.ini"))

