#coding: utf-8

#
#
#    Copyright (C) 2013  INAF -IRA Italian institute of radioastronomy, bartolini@ira.inaf.it
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

COMMON_COSTANTS = dict(
                       WOBUSED = 0,
                       WOBTHROW = 0.0,
                       WOBDIR = '',
                       WOBCYCLE = 0.0,
                       WOBMODE = '',
                       WOBPATT = '',
                       PERIDATE = 0,
                       PERIDIST = 0,
                       LONGASC = 0,
                       OMEGA = 0,
                       INCLINAT = 0,
                       ECCENTR = 0,
                       ORBEPOCH = 0,
                       ORBEQNOX = 0,
                       DISTANCE = 0,
                       NPHASES = 1
                       PHASEn = 'NONE',
                       FRTHRWLO = 0.0,
                       FRTHRWHI = 0.0,
                       TBLANK = 0.0,
                       TSYNC = 0.0,
                      )
"""
Common parameters for every scan. Some of these in the future will be derived
from runtime informations.
"""

