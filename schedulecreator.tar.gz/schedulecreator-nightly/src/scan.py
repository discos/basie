#coding: utf-8

#
#
#    Copyright (C) 2013  INAF -IRA Italian institute of radioastronomy, bartolini@ira.inaf.it
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

"""
Module implementing scan geometries and their methods to get subscans for
specific targets

classes:
    - Scan
        - CrossScan
        - MapScan
            - OTFMapScan
            - RasterMapScan
"""

import logging
logger = logging.getLogger(__name__)
import itertools

import angles

import frame
import subscan
import utils
from valid_angles import ZERO_ANGLE, create_valid_angle

START_POINTS = ('TL', 'TR', 'BL', 'BR')
"""
Valid starting points for Maps geometries
TL = Top Left
TR = Top Roght
BL = Bottom Left
BR = Bottom Right
"""

class Scan(object):
    """
    Base class for all Scan types. Gives a unique ID to the scan and implements
    L{iter_subscans<self.iter_subscans>} method valid for all subclasses.
    """
    ID = 0
    def __init__(self):
        """
        """
        self.ID = Scan.ID
        Scan.ID += 1
        self.unit_subscans = 1
        self.subscans = []
        self.current_target = None
        self.name = "SCAN"

    def __lt__(self, other):
        return self.ID < other.ID

    def __eq__(self, other):
        return self.ID == other.ID

    def __str__(self):
        return "Scan %d type %s" % (self.ID, str(self.__class__))

    def do_scan(self, _target, beamsize=0.3):
        """
        Set the current taraget and calls the L{_do_scan} implementation of the
        specific subclass
        @param _target: the current target
        @type _target: L{target.Target}
        @param beamsize: beamsize for selected receiver and frequency
        @type beamsize: float
        """
        logger.info("scheduling %s on target %s" % (self.name, _target.label))
        if not _target == self.current_target:
            logger.debug("changing target to: %s" % (_target.label,))
            self.subscans = []
            self.current_target = _target
            if not _target.offset_coord.frame:
                try:
                    _target.offset_coord.frame = self.frame
                except:
                    _target.offset_coord.frame = _target.coord.frame
            self._do_scan(_target, beamsize)

    def _do_scan(self, _target, beamsize):
        """
        This is meant to be overridden by subclasses
        Implements logics used to get all the subscans starting from scan and
        target specifications.
        """
        raise NotImplementedError

    def iter_subscans(self, _target, beamsize):
        """
        Loops between subscans inserting tsys subscan when appropriate
        and cycling \"repetitions\" times.
        """
        self.do_scan(_target, beamsize)
        #scan loop
        for rep in xrange(_target.repetitions):
            for sn,ss in enumerate(self.subscans):
                logger.debug("REP: %d SUBSCAN: %d" % (rep, sn))
                subscan_number = rep * self.unit_subscans + sn
                logger.debug("subscan_number %d" % (subscan_number,))
                yield_tsys = False
                if  subscan_number == 0 and _target.tsys >= 0:
                        yield_tsys = True
                elif _target.tsys > 0 and not(subscan_number % _target.tsys):
                    yield_tsys = True
                if yield_tsys:
                    yield ss[1]
                yield ss[0]


class CrossScan(Scan):
    def __init__(self, frame, length, 
                 speed):
        """
        @param frame: The scan L{frame}
        @type frame: L{frame.Frame}
        @param length: length of each otf subscan in decimal degrees
        @type length: angles.Angle
        @param speed: speed of each otf subscan in degrees per minute
        """
        Scan.__init__(self)
        if not isinstance(length, angles.Angle):
            self.length = create_valid_angle(length)
        else:
            self.length = length
        self.frame = frame
        self.speed = speed
        #duration is expressed in seconds
        self.duration = self.length.d / self.speed * 60
        logger.debug("scan %d duration: %f" % (self.ID, self.duration))
        #The minimum observation is composed of 4 subscans
        # to form a cross over the source in both directions
        self.unit_subscans = 4
        self.name = "CROSS SCAN"

    def _do_scan(self, _target, beamsize):
        #Fill informations for each OTF subscan in the 4 directions
        for _const_axis, _direction in [('LON', 'INC'), 
                                        ('LON', 'DEC'), 
                                        ('LAT', 'INC'), 
                                        ('LAT', 'DEC')]:
            self.subscans.append(subscan.get_couple_subscan(_target,
                                                        self.duration,
                                                        self.length,
                                                        ZERO_ANGLE,
                                                        _const_axis,
                                                        _direction,
                                                        self.frame,
                                                        beamsize))

class MapScan(Scan):
    """
    MapScan superclass used for OTF and RASTER maps
    """
    def __init__(self, frame, start_point, scan_axis,
              length_x, length_y, spacing):
        """
        Constructor
        @param frame: scan frame
        @type frame: frame.Frame
        @param start_point: one of TL, TR, BL, BR
        @param scan_axis: one of LON LAT RA DEC AZ EL BOTH, the constant axis of
        each subscan
        @param length_x: map width in degrees
        @type length_x: angles.Angle
        @param length_y: map height in degrees
        @type length_y: angles.Angle
        @param spacing: offset between each subscan in degrees
        @type spacing: angles.Angle
        """
        Scan.__init__(self)
        self.frame = frame
        self.start_point = start_point
        self.scan_axis = scan_axis
        self.length_x = length_x
        self.length_y = length_y
        self.spacing = spacing
        self.dimension_x = utils.ceil_to_odd(self.length_x.d / self.spacing.d)
        self.dimension_y = utils.ceil_to_odd(self.length_y.d / self.spacing.d)
        logger.debug("%d dim_x %d dim_y %d" % (self.ID, self.dimension_x,
                                               self.dimension_x))
        self.offset_x = [create_valid_angle(i * self.spacing.d) 
                         for i in range(-1 * (self.dimension_x // 2), 
                                        (self.dimension_x // 2) + 1)]
        self.offset_y = [create_valid_angle(i * self.spacing.d) 
                         for i in range(-1 * (self.dimension_y // 2), 
                                        (self.dimension_y // 2) + 1)]

class OTFMapScan(MapScan):
    def __init__(self, frame, start_point, scan_axis, 
                 length_x, length_y, spacing, speed):
        MapScan.__init__(self, frame, start_point,
                         scan_axis, length_x, length_y, spacing)
        self.speed = speed
        self.duration_x = self.length_x.d / self.speed * 60
        self.duration_y = self.length_y.d / self.speed * 60
        if scan_axis == "LON":
            self.unit_subscans = self.dimension_y
        elif scan_axis == "LAT":
            self.unit_subscans = self.dimension_x
        self.name = "OTF MAP SCAN"
    
    def _do_scan(self, _target, beamsize):
        
        logger.debug("scan axis: %s" % (self.scan_axis,))

        if self.scan_axis == self.frame.lon_name or self.scan_axis == "LON":
            _const_axis = 'LAT'
            if self.start_point == "TL" or self.start_point == "TR":
                _offsets = reversed(self.offset_y)
            else:
                _offsets = self.offset_y
            if self.start_point == "TL" or self.start_point == "BL":
                if self.frame == frame.EQ or self.frame == frame.GAL: #RA and GAL-LON are reversed!!
                    _directions = ("DEC", "INC")
                else:
                    _directions = ("INC", "DEC")
            else:
                if self.frame == frame.EQ or self.frame == frame.GAL:
                    _directions = ("INC", "DEC")
                else:
                    _directions = ("DEC", "INC")
            for _offset, _direction in itertools.izip(_offsets,
                                                      itertools.cycle(_directions)):
                logger.debug("OTF: %d offset %s direction %s" % (self.ID,
                                                                 _offset,
                                                                 _direction))
                self.subscans.append(subscan.get_couple_subscan(_target,
                                                            self.duration_x,
                                                            self.length_x,
                                                            _offset,
                                                            _const_axis,
                                                            _direction,
                                                            self.frame,
                                                            beamsize))
        elif self.scan_axis == self.frame.lat_name or self.scan_axis == "LAT":
            _const_axis = 'LON'
            if self.start_point == "TR" or self.start_point == "BR":
                if self.frame == frame.EQ or self.frame == frame.GAL:
                    _offsets = self.offset_x
                else:
                    _offsets = reversed(self.offset_x)
            else:
                if self.frame == frame.EQ or self.frame == frame.GAL:
                    _offsets = reversed(self.offset_x)
                else:
                    _offsets = self.offset_x
            if self.start_point == "BL" or self.start_point == "BR":
                _directions = ("INC", "DEC")
            else:
                _directions = ("DEC", "INC")
            for _offset, _direction in itertools.izip(_offsets,
                                                      itertools.cycle(_directions)):
                logger.debug("OTF: %d offset %s direction %s" % (self.ID,
                                                                 _offset,
                                                                 _direction))
                self.subscans.append(subscan.get_couple_subscan(_target,
                                                            self.duration_y,
                                                            self.length_y,
                                                            _offset,
                                                            _const_axis,
                                                            _direction,
                                                            self.frame,
                                                            beamsize))

class RasterMapScan(MapScan):
    def __init__(self, frame, start_point, scan_axis, 
                 length_x, length_y, spacing, duration):
        MapScan.__init__(self, frame, start_point, scan_axis,
                  length_x, length_y, spacing)
        self.duration = duration
        self.extremes = list(itertools.product(
                                               [self.offset_x[0].d,
                                                self.offset_x[-1].d],
                                               [self.offset_y[0].d,
                                                self.offset_y[-1].d]
                                              ))
        self._offsets = self._get_offsets()
        self.name = "RASTER MAP SCAN"

    def _get_offsets(self):
        """
        Get ordered offsets for each point of the raster scan
        @return: [(X0, Y0), (X1, Y1) .... (Xdim, Ydim)]
        """
        res = [] #resulting offsets
        if self.start_point == "TL" or self.start_point == "BL":
            if self.frame == frame.EQ or self.frame == frame.GAL:
                xoffsets = list(reversed(self.offset_x))
            else:
                xoffsets = self.offset_x
        else:
            if self.frame == frame.EQ or self.frame == frame.GAL:
                xoffsets = self.offset_x
            else:
                xoffsets = list(reversed(self.offset_x))
        if self.start_point == "TL" or self.start_point == "TR":
            yoffsets = list(reversed(self.offset_y))
        else:
            yoffsets = self.offset_y

        if self.scan_axis == "LON" or self.scan_axis == self.frame.lon_name:
            for i, _y in enumerate(yoffsets):
                if i % 2 == 0:
                    _xoffsets = xoffsets
                else:
                    _xoffsets = reversed(xoffsets)
                for _x in _xoffsets:
                    res.append((_x, _y))
        elif self.scan_axis == "LAT" or self.scan_axis == self.frame.lat_name:
            for i, _x in enumerate(xoffsets):
                if i % 2 == 0:
                    _yoffsets = yoffsets
                else:
                    _yoffsets = reversed(yoffsets)
                for _y in _yoffsets:
                    res.append((_x, _y))
        for _x, _y in res:
            logger.debug("\toffset\t %f\t%f" % (_x.d, _y.d))
        return res

    def _do_scan(self, _target, beamsize):
        for offset_lon, offset_lat in self._offsets:
            for _x, _y in self._offsets:
                logger.debug("\toffset\t %f\t%f" % (_x.d, _y.d))
            logger.debug("OFFSETS: %f %f" % (offset_lon.d, offset_lat.d))
            self.subscans.append(subscan.get_sid_couple_subscan(_target, 
                                                                offset_lon,
                                                                offset_lat,
                                                                self.extremes,
                                                                self.duration,
                                                                beamsize))

