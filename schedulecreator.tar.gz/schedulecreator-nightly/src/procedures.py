#coding=utf-8

#
#
#    Copyright (C) 2013  INAF -IRA Italian institute of radioastronomy, bartolini@ira.inaf.it
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

TSYS_WAIT_TIME = 2
"""
Time to wait before issuing a tsys command (sec.)
"""

class Procedure(object):
    """Class representing a procedure template.
    Remeber that the module already defines some standard procedures!
    Use it like this:

        >>> import procedures
        >>> myproc = procedures.Procedure(\"myp\", 1, \"\\tcomm=$1\\n\\tend_comm\\n\")
        >>> str(myproc) 
        \'MYP(1){\\n\\tcomm=$1\\n\\tend_comm\\n}\\n\'
        >>> myproc(10)  
        \'MYP=10\'


    """
    def __init__(self, name, nparams, body):
        """
        Constructor.
        @param name: name of the procedure as will be defined in schedule files
        @param nparams: number of parameters accepted by the procedure
        @param body: the body of the procedure, that's to say the list of
        commands the procedure executes
        """
        self.name = name.upper()
        self.nparams = nparams
        self.body = body

    def __str__(self):
        """
        Used for getting the procedure definition as it must be added to the
        .cfg schedule file
        """
        res = str(self.name)
        if self.nparams > 0:
            res += "(%d)" % self.nparams
        res += "{\n"
        res += self.body
        res += "}\n"
        return res

    def __call__(self, *args):
        """
        Used to get the procedure syntax as it has to be called from within the
        .scd schedule file
        """
        if not len(args) == self.nparams:
            raise TypeError("Procedure %s takes exactly %d params (%d given)" %
                            (self.name, self.nparams, len(args)))
        res = self.name
        if self.nparams > 0:
            res += '=' 
            for _arg in args:
                res += str(_arg) + ","
            res = res[:-1]
        return res

WAIT = Procedure("procedure_wait", 1, "\twait=$1\n")
"""
Standard B{wait} procedure
"""
TSYS = Procedure("procedure_tsys", 0, "\twait=%f\n\ttsys\n\twait=1\n" % (TSYS_WAIT_TIME,))
"""
Standard B{tsys} procedure
"""


