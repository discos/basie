#coding=utf-8

#
#
#    Copyright (C) 2013  INAF -IRA Italian institute of radioastronomy, bartolini@ira.inaf.it
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

"""
Module containig target objects definitions and logics for parsing target
specified in a text file
exposed classes: 
    - TargetError
    - Target 
"""

import re
import logging
logger = logging.getLogger(__name__)

import valid_angles
import rich_validator
import frame as fr

"""
string pattern identifying an option.
Matches everything separated by a \'=\' sign excluding whitespaces
"""
OPTION_RE = "(?P<opt>\S+)\s*=\s*(?P<val>\S+)\s*"

"""
string pattern identifying a target line.
The line must be composed of \'label\' \'scantype\' \'frame\' \'longitude\'
\'latitude\' and multiple \'key = value\' optional parameters.
"""
TARGET_RE = "^(?P<label>\S+)\s+" + \
            "(?P<scantype>\S+)\s+" + \
            "(?P<frame>eq|hor|gal)\s+" +\
            "(?P<longitude>\S+)\s+" +\
            "(?P<latitude>\S+)\s*" +\
            "(?P<optionals>.*)$"

TARGET_PATTERN = re.compile(TARGET_RE, re.I)
OPTION_PATTERN = re.compile(OPTION_RE)

class TargetError(Exception):
    def __init__(self, *args, **kwargs):
        Exception.__init__(self, *args, **kwargs)

class Target(object):
    def __init__(self, label, frame, longitude, latitude, 
                 epoch = "2000", #only value permitted in schedulecreator
                 offset_frame = None,
                 offset_lon = valid_angles.create_valid_angle(0.0),
                 offset_lat = valid_angles.create_valid_angle(0.0),
                 repetitions = None, #default value should evaluate to False
                 tsys = None): #default value should evaluate to False
        """
        Constructor
        @param label: target name
        @param frame: target coordinate frame
        @type frame: frame.Frame
        @param longitude: target longitude
        @type longitude: anlges.Angle (valid_angles.create_valid_angle( ... ))
        @param latitude: target longitude
        @type latitude: anlges.Angle (valid_angles.create_valid_angle( ... ))
        """
        self.label = label
        self.coord = fr.Coord(frame, longitude, latitude)
        #TODO: does it make sense to store these parameters here?
        self.repetitions = repetitions
        self.tsys = tsys
        self.offset_coord = fr.Coord(offset_frame, offset_lon, offset_lat)
        logger.debug(str(self))
        logger.debug("offset: %s %s" % (self.offset_coord.lon,
                                        self.offset_coord.lat,))
        self.epoch = epoch

    def __str__(self):
        _lon, _lat = self.coord.fmt()
        res = "target %s lon: %s lat: %s" % (self.label, _lon, _lat)
        return res
        
    def transform(self, dest_frame):
        if not isinstance(dest_frame, fr.Frame):
            dest_frame = fr.frames[dest_frame.upper()]
        logger.debug("transform coordinates of target %s from %s to %s" %
                     (self.label, self.coord.frame.name, dest_frame.name,))
        self.coord.transform(dest_frame)

def copy(other):
    _coord = fr.copy_coord(other.coord)
    _offset_coord = fr.copy_coord(other.offset_coord)
    return Target(other.label, _coord.frame, _coord.lon, _coord.lat, other.epoch,
               offset_frame = _offset_coord.frame, offset_lon =
               _offset_coord.lon, offset_lat = _offset_coord.lat, repetitions =
               other.repetitions, tsys=other.tsys)

def check_consistency(target):
    """
    if FRAME = HOR and LON is hours => error
    if FRAME = EQ|GAL ==> 0 < deg < 360 per LON && -90 < deg < 90 per LAT
    (posso controllarlo dopo averli trasformati in angoli - occhio che si leggono
    anche le ore!!!
    if FRAME = HOR ==> 0 < deg < 360 per AZ && 0 < deg < 90 per EL
    """
    if target.coord.frame == fr.HOR:
        if target.coord.lon.fmt == "hms":
            raise TargetError("Horizontal frame does not accept longitude hours")
    if not (0 <= target.coord.lon.d <= 360):
        raise TargetError("Longitude must be 0 <= lon <= 360")
    if target.coord.frame == fr.EQ or target.coord.frame == fr.GAL:
        if not (-90 <= target.coord.lat.d <= 90):
            raise TargetError("Latitude must be -90 <= lat <= 90")
    else:
        if not (0 <= target.coord.lat.d <= 90):
            raise TargetError("Latitude must be 0 <= lat <= 90")

def _parse_options(line):
    """
    parse optional parameters from target line. 
    Options are specified as key-value pairs, key can be one of: 
    repetitions, tsys, offset_frame, offset_lon, offset_lat
    """
    options = {}
    matches = OPTION_PATTERN.findall(line)
    for key, val in matches:
        if key == 'offset_lon':
            options['offset_lon'] = valid_angles.check_dec_angle(val)
        elif key == 'offset_lat':
            options['offset_lat'] = valid_angles.check_dec_angle(val)
        elif key == 'tsys':
            options['tsys'] = int(val)
        elif key == 'repetitions':
            options['repetitions'] = int(val)
        elif key == 'offset_frame':
            options['offset_frame'] = rich_validator.check_frame(val)
    return options

def _parse_target_line(line):
    """
    Validate and parse a line of a txt file specifying a target
    of the schedule
    """
    matches = TARGET_PATTERN.match(line)
    if not matches:
        logger.warning("invalid target line: " + line)
        return None, None
    else:
        logger.info("parsing target line: " + line)
        target = matches.groupdict()
        option_string = target.pop('optionals')
        target['frame'] = rich_validator.check_frame(target['frame'])
        target['longitude'] = valid_angles.check_angle(target['longitude'])
        target['latitude'] = valid_angles.check_angle(target['latitude'])
        target.update(_parse_options(option_string))
        scantype = target.pop("scantype")
        return (scantype, Target(**target))

def parse(filename, check_values=True):
    """
    Parse a target txt file into a list of Target objects.
    """
    _file = open(filename, "r")
    lines = _file.readlines()
    _file.close()
    #escapes whitespaces and special chars
    lines = [l.strip() for l in lines]
    #remove commented and empty lines
    lines = [l for l in lines if ((not l.startswith("#")) and (not l == ""))]
    targets = [] #targets is a list so that it mantains the same ordering as in the file lines
    for l in lines:
        scantype, target = _parse_target_line(l)
        if target: # not None
            if check_values:
                check_consistency(target)
            targets.append((target, scantype, l))
    return targets

if __name__ == "__main__":
    #Implements testing logics
    logging.basicConfig(level=logging.DEBUG)
    targets = parse("user_templates/targets.txt")
    for t in targets:
        print t[1], t[0]
